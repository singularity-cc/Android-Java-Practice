package com.myexample.zhhyok.currencyconverter;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    public void currencyConvert(View view) {
        EditText editText = (EditText) findViewById(R.id.editText);
        String doll;
        doll = editText.getText().toString();
        float d = Float.parseFloat(doll);
        float p = d * 1.3f;
        String pound = Float.toString(p);
        Log.i("Info", "Submitted");

        Toast.makeText(this, pound, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
