package com.myexample.zhhyok.numbershapes;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    class Number {
        int n;

        public boolean squareCheck() {
            double m = (double) n;
            double res = Math.sqrt(m);
            return (res - Math.floor(res) == 0);
        }

        public boolean triangleCheck(){
            Number x = new Number();
            x.n = 8 * n + 1;
            return x.squareCheck();
        }
    };


    public void submitFunction(View view) {
        EditText number = findViewById(R.id.editText);
        String numberString = number.getText().toString();
        String message1;
        if (numberString.isEmpty()) {
            message1 = "Please enter a number.";
            Toast.makeText(this, message1, Toast.LENGTH_SHORT).show();
            return;
        }
        int numberInt = Integer.parseInt(numberString);
        Log.i("Info", numberString);


        Number i = new Number();
        i.n = numberInt;
        if (i.squareCheck() && i.triangleCheck()) {
            message1 = numberString + " is Square and Triangle Number!";
        } else if (i.squareCheck()) {
            message1 = numberString + " is Square Number!";
        } else if (i.triangleCheck()) {
            message1 = numberString + " is Triangle Number!";
        } else {
            message1 = numberString + " is Neither!";
        }
        Toast.makeText(this, message1, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
