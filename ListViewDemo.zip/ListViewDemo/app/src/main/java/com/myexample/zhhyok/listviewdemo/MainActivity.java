package com.myexample.zhhyok.listviewdemo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.*;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ListView friendListView = findViewById(R.id.friendListView);

        final ArrayList<String> friend = new ArrayList<String>();
        friend.add("Julia");
        friend.add("Shibi");
        friend.add("Okar");

        ArrayAdapter adapterFriend = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, friend);
        friendListView.setAdapter(adapterFriend);

        friendListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Log.i("Info", friend.get(i).toString());
                Toast.makeText(MainActivity.this, friend.get(i).toString(), Toast.LENGTH_SHORT).show();
            }
        });


    }
}
