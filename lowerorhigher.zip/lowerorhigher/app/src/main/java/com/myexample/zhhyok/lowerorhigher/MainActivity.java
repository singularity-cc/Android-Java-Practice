package com.myexample.zhhyok.lowerorhigher;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.util.*;

public class MainActivity extends AppCompatActivity {
    public void submitFunction(View view) {
        Random rand = new Random();
        rand.setSeed(1);
        int upperbound = 20;
        int target = rand.nextInt(upperbound) + 1;
        EditText guessText = findViewById(R.id.numEditText);
        String guessTextString = guessText.getText().toString();
        int guessTextInt = Integer.parseInt(guessTextString);
        if (guessTextInt < target) {
            Toast.makeText(this, "Higher", Toast.LENGTH_LONG).show();
        } else if (guessTextInt > target) {
            Toast.makeText(this, "Lower", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Correct!", Toast.LENGTH_SHORT).show();
        }
        System.out.println(target);
        Log.i("Info", "Submitted!");
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
